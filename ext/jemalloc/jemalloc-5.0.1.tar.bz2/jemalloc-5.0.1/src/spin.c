#define JEMALLOC_SPIN_C_
#include "jemalloc/internal/jemalloc_preamble.h"

#include "jemalloc/internal/spin.h"
